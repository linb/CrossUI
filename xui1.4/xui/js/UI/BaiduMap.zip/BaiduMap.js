Class("xui.UI.BaiduMap", "xui.UI",{
    Instance:{
        getBMap:function(){
            return this.get(0)._bmap;
        }
    },
    Static:{
        Appearances:{
            KEY:{
                'font-size':xui.browser.ie?0:null,
                'line-height':xui.browser.ie?0:null,
                overflow:'hidden'
            }
        },
        Templates:{
            tagName:'div',
            className:'{_className}',
            style:'{_style}'
        },
        Behaviors:{
            HotKeyAllowed:false
        },
        DataModel:{
            selectable:true,
            width:300,
            height:200,
            src:{
                ini:'http://api.map.baidu.com/getscript',
                action:function(){
                    this.refresh();
                }
            },
            ak:{
                ini: "E4805d16520de693a3fe707cdc962045",
                action:function(){
                    this.refresh();
                }
            },
            v:{
                ini: "2.0",
                action:function(){
                    this.refresh();
                }
            },
            longitude:{
                ini: 116.331398,
                action:function(){
                    this._bmap.centerAndZoom(new BMap.Point(this.properties.longitude, this.properties.latitude),11);
                }
            },
            latitude:{
                ini: 39.897445,
                action:function(){
                    this._bmap.centerAndZoom(new BMap.Point(this.properties.longitude, this.properties.latitude),11);
                }
            }
        },
        RenderTrigger:function(){
            var prf = this,
                domId = prf.domId,
                root = prf.getRoot(),
                prop = prf.properties;
            var initMap = function(){
                var map = new BMap.Map(domId);
                map.centerAndZoom(new BMap.Point(prop.longitude, prop.latitude),11);
                map.enableScrollWheelZoom(true);
                var top_left_control = new BMap.ScaleControl({anchor: BMAP_ANCHOR_TOP_LEFT});
                var top_left_navigation = new BMap.NavigationControl(); 
                var top_right_navigation = new BMap.NavigationControl({anchor: BMAP_ANCHOR_TOP_RIGHT, type: BMAP_NAVIGATION_CONTROL_SMALL});
    
                map.addControl(top_left_control);        
                map.addControl(top_left_navigation);     
                map.addControl(top_right_navigation);    
 
                prf._bmap = map;
            };

            if(!window.BMap){
                xui.include("BMap", prop.src, function(){
                    if(window.BMap){
                        initMap();
                    }
                },null,false,{query:{
                    v: prop.v, 
                    ak: prop.ak, 
                    services: "",
                    t: xui.Date.format(new Date ,"yyyymmddhhmmss")
                }});
            }else{
                initMap();
            }
        },
        EventHandlers:{
            onMapEvent:function(profile, eventType, params){}
        },
        _onresize:function(profile,width,height){
            
        }
    }
});